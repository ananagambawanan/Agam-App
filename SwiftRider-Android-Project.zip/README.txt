SWIFTRIDER ANDROID STARTER

This is an Android project that builds an installable debug APK through GitHub Actions.
It is a working local demo: online/offline toggle, sample order list, accept, pickup, complete, and earnings.
IMPORTANT: It is NOT connected to real restaurants, a dispatch server, rider accounts, GPS tracking, or payments. Do not use it for real deliveries yet.

BUILD APK USING ONLY YOUR ANDROID PHONE:
1. Extract this ZIP.
2. Open https://github.com and create a new PUBLIC repository named SwiftRider (or private if your account supports Actions).
3. In the repository choose Add file > Upload files. Upload the CONTENTS of this folder, keeping folder structure. Commit.
4. Open the repository's Actions tab. Select "Build SwiftRider APK" and wait for the green check.
5. Open that completed workflow run, scroll to Artifacts, download "SwiftRider-APK".
6. Extract the downloaded artifact ZIP and tap app-debug.apk to install. Android may ask you to allow installs from your browser/files app.

No computer required, but GitHub account and internet are required.
